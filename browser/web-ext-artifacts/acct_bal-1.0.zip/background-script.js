browser.browserAction.onClicked.addListener(() => {
	browser.tabs.executeScript({file: "/acct.js"})
		// .then(listenForClicks)
		// .catch(reportExecuteScriptError);
//todo errors lol
});


/*
  "content_scripts": [
    {
      "matches": ["*://secure.onlinegoamplify.com/*"],
      "js": ["acct.js"]
    }
  ]*/