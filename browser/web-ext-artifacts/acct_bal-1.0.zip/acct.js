//content script
// alert('lol')
(async () => {
	let find = (searchText, selector = '*') => {
		var els = document.querySelectorAll(selector);
		console.log(els.length)
		for (var i = 0; i < els.length; i++) {
			if (els[i].textContent.trim() == searchText) {
				return els[i];
			}
		}
	}

	//https://stackoverflow.com/questions/2705583/how-to-simulate-a-click-with-javascript

	function eventFire(el, etype){
	  if (el.fireEvent) {
	    el.fireEvent('on' + etype);
	  } else {
	    var evObj = document.createEvent('Events');
	    evObj.initEvent(etype, true, false);
	    el.dispatchEvent(evObj);
	  }
	}

	function keyPress (el, key) {
		var evObj = document.createEvent('KeyboardEvent');
		evObj.initEvent(etype, true, false);
		el.dispatchEvent(evObj);
	}

	sleep = (msec) =>  {
		return new Promise(res => setTimeout(res, msec))
	}

	// https://stackoverflow.com/questions/10911526/how-do-i-change-an-html-selected-option-using-javascript

	function setSelectBoxByText(el, etxt) {
	    for (var i = 0; i < el.options.length; ++i) {
	        if (el.options[i].text.includes(etxt))
	            el.options[i].selected = true;
	    }
	}

	//////


	let properties = [
		{
			name: "205 W Avenue A",
			balance: 0,
		},
		{
			name: "505 Traci",
			balance: 0,
		},
		{
			name: "4106 Michigan",
			balance: 0,
		},
		{
			name: "2211 Coach Drive",
			balance: 0,
		},
	]

	properties.forEach(p => {
		let rawDollars = document.querySelector(`[title="${p.name}"]`).closest('.tile-card-account').querySelector('.currency').textContent
		// let rawDollars = p.name == "2211 Coach Drive"? 2000.13:2000;
		rawDollars = rawDollars.replace(/[^0-9.]/g,'')
		p.balance = Number(rawDollars)
		p.transferAmt = Math.round((p.balance - 2000)*100)/100
		console.log(`${Math.abs(p.transferAmt)} ${p.transferAmt > 0 ? 'from':'to'} ${p.name}`)
		// alert(p + ' has ' + Number(rawDollars))
	})

	console.log(find('Transfer Money Now', '.btn'))
	eventFire(find('Transfer Money Now', '.btn'), 'click');

	for (let i = 0; i < properties.length; i++) {
		// for each property, do the transfer
		let property = properties[i]
		if (property.transferAmt == 0) {
			// alert('skipping ' + property.name)
			continue;
		}
		let fromTo = property.transferAmt > 0 ? [property.name, 'Central Properties Reserve'] : ['Central Properties Reserve', property.name];
		let fromSelect;
		while (!fromSelect) {
			await sleep(100)
			fromSelect = document.querySelector('[test-id="selFromAccount"]')
			// console.log(selFromAccount)
		}

		setSelectBoxByText(fromSelect, fromTo[0])
		let inputEvent = new Event('change', {
			bubbles: true,
			cancelable: true,
		});
		fromSelect.dispatchEvent(inputEvent);

		let toSelect;
		while (!toSelect) {
			await sleep(100)
			toSelect = document.querySelector('[test-id="selToAccount"]')
			// console.log(selFromAccount)
		}

		setSelectBoxByText(toSelect, fromTo[1])
		inputEvent = new Event('change', {
			bubbles: true,
			cancelable: true,
		});
		toSelect.dispatchEvent(inputEvent);


		alert('transfer ing ' + property.transferAmt)
		document.querySelector('input.amount').value = Math.abs(property.transferAmt)
		// const evt = new KeyboardEvent('keypress', {
		// 	key: '6',
		// 	code: 54,
		// 	charCode: 54,
		// 	keyCode: 54
		// })
		// document.querySelector('input.amount').dispatchEvent(evt);

		inputEvent = new Event('change', {
			bubbles: true,
			cancelable: true,
		});
		document.querySelector('input.amount').dispatchEvent(inputEvent);


		document.querySelector('input[test-id="fldMemo"]').value = 'bot bal beep beep'
		inputEvent = new Event('change', {
			bubbles: true,
			cancelable: true,
		});
		document.querySelector('input[test-id="fldMemo"]').dispatchEvent(inputEvent);

		const submitButton = document.querySelector('button[test-id="btnTransferFunds"]')
		eventFire(submitButton, 'click');

		let closeModalBtnEl;
		while (!closeModalBtnEl) {
			await sleep(100)
			closeModalBtnEl = document.querySelector('[test-id="btnModalButton2"]')
			// console.log(selFromAccount)
		}
		eventFire(closeModalBtnEl, 'click');
	}

	
})()